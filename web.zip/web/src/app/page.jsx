"use client";

import { useState, useEffect } from "react";
import {
  GitBranch,
  Plus,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ExternalLink,
} from "lucide-react";

export default function Dashboard() {
  const [repositories, setRepositories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    fetchRepositories();
  }, []);

  const fetchRepositories = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/repositories/list");
      if (!response.ok) throw new Error("Failed to fetch repositories");
      const data = await response.json();
      setRepositories(data.repositories || []);
    } catch (error) {
      console.error("Error fetching repositories:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen font-inter"
      style={{
        background:
          "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
      }}
    >
      {/* Header */}
      <div className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-slate-900">
                Version Tracker
              </h1>
              <p className="text-sm text-slate-600 mt-1">
                Track GitHub commits and Vercel deployments
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={fetchRepositories}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </button>
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Repository
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="flex items-center gap-3 text-slate-600">
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Loading repositories...</span>
            </div>
          </div>
        ) : repositories.length === 0 ? (
          <div className="text-center py-20">
            <GitBranch className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              No repositories yet
            </h3>
            <p className="text-slate-600 mb-6">
              Add your first repository to start tracking versions
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Repository
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {repositories.map((repo) => (
              <RepositoryCard
                key={repo.id}
                repository={repo}
                onUpdate={fetchRepositories}
              />
            ))}
          </div>
        )}
      </div>

      {/* Add Repository Modal */}
      {showAddModal && (
        <AddRepositoryModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            fetchRepositories();
          }}
        />
      )}

      <style jsx global>{`
        .font-inter {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
      `}</style>
    </div>
  );
}

function RepositoryCard({ repository, onUpdate }) {
  const [syncing, setSyncing] = useState(false);

  const syncRepository = async () => {
    try {
      setSyncing(true);

      // Fetch commits and deployments in parallel
      await Promise.all([
        fetch("/api/github/fetch-commits", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ repository_id: repository.id }),
        }),
        fetch("/api/vercel/fetch-deployments", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ repository_id: repository.id }),
        }),
      ]);

      onUpdate();
    } catch (error) {
      console.error("Error syncing repository:", error);
    } finally {
      setSyncing(false);
    }
  };

  const lastSynced = repository.last_synced_at
    ? new Date(repository.last_synced_at).toLocaleString()
    : "Never";

  return (
    <a href={`/repository/${repository.id}`}>
      <div className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-lg transition-shadow cursor-pointer group">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <GitBranch className="w-4 h-4 text-slate-500 flex-shrink-0" />
              <h3 className="text-sm font-medium text-slate-900 truncate group-hover:text-slate-700">
                {repository.github_owner}/{repository.github_repo}
              </h3>
            </div>
            <p className="text-xs text-slate-500 truncate">
              Vercel: {repository.vercel_project_id}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-600">
            <Clock className="w-3.5 h-3.5" />
            <span>{lastSynced}</span>
          </div>

          <button
            onClick={(e) => {
              e.preventDefault();
              syncRepository();
            }}
            disabled={syncing}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors disabled:opacity-50"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${syncing ? "animate-spin" : ""}`}
            />
            {syncing ? "Syncing..." : "Sync"}
          </button>
        </div>
      </div>
    </a>
  );
}

function AddRepositoryModal({ onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    github_owner: "",
    github_repo: "",
    github_token_env_var: "GITHUB_TOKEN",
    vercel_project_id: "",
    vercel_token_env_var: "VERCEL_TOKEN",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/repositories/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to create repository");
      }

      onSuccess();
    } catch (err) {
      console.error("Error creating repository:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center p-4 z-50 bg-black/20 backdrop-blur-sm">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-2xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">
            Add Repository
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Connect a GitHub repo and Vercel project
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-1.5">
              GitHub Owner
            </label>
            <input
              type="text"
              required
              value={formData.github_owner}
              onChange={(e) =>
                setFormData({ ...formData, github_owner: e.target.value })
              }
              placeholder="octocat"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-1.5">
              GitHub Repository
            </label>
            <input
              type="text"
              required
              value={formData.github_repo}
              onChange={(e) =>
                setFormData({ ...formData, github_repo: e.target.value })
              }
              placeholder="my-project"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-1.5">
              GitHub Token (env var name)
            </label>
            <input
              type="text"
              required
              value={formData.github_token_env_var}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  github_token_env_var: e.target.value,
                })
              }
              placeholder="GITHUB_TOKEN"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
            />
            <p className="text-xs text-slate-500 mt-1">
              Name of the environment variable containing your GitHub token
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-1.5">
              Vercel Project ID
            </label>
            <input
              type="text"
              required
              value={formData.vercel_project_id}
              onChange={(e) =>
                setFormData({ ...formData, vercel_project_id: e.target.value })
              }
              placeholder="prj_xxxxxxxxxxxxx"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-900 mb-1.5">
              Vercel Token (env var name)
            </label>
            <input
              type="text"
              required
              value={formData.vercel_token_env_var}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  vercel_token_env_var: e.target.value,
                })
              }
              placeholder="VERCEL_TOKEN"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
            />
            <p className="text-xs text-slate-500 mt-1">
              Name of the environment variable containing your Vercel token
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Adding..." : "Add Repository"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
