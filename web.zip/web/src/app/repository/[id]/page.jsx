"use client";

import { useState, useEffect } from "react";
import {
  ArrowLeft,
  GitBranch,
  GitCommit,
  Rocket,
  AlertTriangle,
  CheckCircle2,
  Download,
  RefreshCw,
  ExternalLink,
  FileCode,
  TrendingUp,
} from "lucide-react";
import { use } from "react";

export default function RepositoryDetail({ params }) {
  const resolvedParams = use(params);
  const repositoryId = parseInt(resolvedParams.id);

  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [comparing, setComparing] = useState(false);

  useEffect(() => {
    fetchStatus();
  }, [repositoryId]);

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/repositories/get-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repository_id: repositoryId }),
      });

      if (!response.ok) throw new Error("Failed to fetch status");

      const data = await response.json();
      setStatus(data);
    } catch (error) {
      console.error("Error fetching status:", error);
    } finally {
      setLoading(false);
    }
  };

  const syncAll = async () => {
    try {
      setSyncing(true);

      await Promise.all([
        fetch("/api/github/fetch-commits", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            repository_id: repositoryId,
            num_commits: 20,
          }),
        }),
        fetch("/api/vercel/fetch-deployments", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ repository_id: repositoryId, limit: 20 }),
        }),
      ]);

      await fetchStatus();
    } catch (error) {
      console.error("Error syncing:", error);
    } finally {
      setSyncing(false);
    }
  };

  const compareLatest = async () => {
    if (!status?.latest_commit || !status?.latest_deployment) return;

    try {
      setComparing(true);

      const response = await fetch("/api/github/compare-commits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          repository_id: repositoryId,
          base_sha: status.latest_deployment.commit_sha,
          head_sha: status.latest_commit.sha,
        }),
      });

      if (!response.ok) throw new Error("Failed to compare");

      const data = await response.json();

      // Navigate to comparison view
      window.location.href = `/comparison/${data.diff_analysis_id}`;
    } catch (error) {
      console.error("Error comparing:", error);
    } finally {
      setComparing(false);
    }
  };

  if (loading) {
    return (
      <div
        className="min-h-screen font-inter flex items-center justify-center"
        style={{
          background:
            "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
        }}
      >
        <div className="flex items-center gap-3 text-slate-600">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span>Loading repository...</span>
        </div>
      </div>
    );
  }

  if (!status) {
    return (
      <div
        className="min-h-screen font-inter flex items-center justify-center"
        style={{
          background:
            "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
        }}
      >
        <div className="text-center">
          <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900 mb-2">
            Repository not found
          </h3>
          <a href="/" className="text-sm text-slate-600 hover:text-slate-900">
            Back to dashboard
          </a>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen font-inter"
      style={{
        background:
          "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
      }}
    >
      {/* Header */}
      <div className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/"
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </a>
              <div>
                <div className="flex items-center gap-2">
                  <GitBranch className="w-5 h-5 text-slate-500" />
                  <h1 className="text-xl font-semibold text-slate-900">
                    {status.repository.github_owner}/
                    {status.repository.github_repo}
                  </h1>
                </div>
                <p className="text-sm text-slate-600 mt-1">
                  Vercel: {status.repository.vercel_project_id}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={syncAll}
                disabled={syncing}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
              >
                <RefreshCw
                  className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`}
                />
                {syncing ? "Syncing..." : "Sync All"}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {/* Mismatch Alert */}
          {status.has_mismatch && (
            <div className="md:col-span-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-semibold text-amber-900">
                      Version Mismatch Detected
                    </h3>
                    <p className="text-sm text-amber-800 mt-1">
                      Your latest GitHub commit is different from the deployed
                      version on Vercel
                    </p>
                  </div>
                </div>
                <button
                  onClick={compareLatest}
                  disabled={comparing}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors disabled:opacity-50"
                >
                  <FileCode className="w-4 h-4" />
                  {comparing ? "Comparing..." : "Compare"}
                </button>
              </div>
            </div>
          )}

          {/* Latest Commit */}
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <GitCommit className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-semibold text-slate-900">
                Latest Commit
              </h3>
            </div>
            {status.latest_commit ? (
              <div>
                <p className="text-xs font-mono text-slate-600 mb-2">
                  {status.latest_commit.sha.substring(0, 8)}
                </p>
                <p className="text-sm text-slate-900 line-clamp-2 mb-2">
                  {status.latest_commit.message}
                </p>
                <p className="text-xs text-slate-500">
                  by {status.latest_commit.author_name}
                </p>
              </div>
            ) : (
              <p className="text-sm text-slate-500">No commits synced yet</p>
            )}
          </div>

          {/* Latest Deployment */}
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Rocket className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-semibold text-slate-900">
                Latest Deployment
              </h3>
            </div>
            {status.latest_deployment ? (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span
                    className={`inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded-full ${
                      status.latest_deployment.state === "READY"
                        ? "bg-emerald-100 text-emerald-800"
                        : "bg-slate-100 text-slate-800"
                    }`}
                  >
                    {status.latest_deployment.state === "READY" && (
                      <CheckCircle2 className="w-3 h-3" />
                    )}
                    {status.latest_deployment.state}
                  </span>
                </div>
                <p className="text-xs font-mono text-slate-600 mb-2">
                  {status.latest_deployment.commit_sha?.substring(0, 8) ||
                    "N/A"}
                </p>
                {status.latest_deployment.url && (
                  <a
                    href={`https://${status.latest_deployment.url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800"
                  >
                    View deployment
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            ) : (
              <p className="text-sm text-slate-500">
                No deployments synced yet
              </p>
            )}
          </div>

          {/* Recent Analyses */}
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-semibold text-slate-900">
                Recent Analyses
              </h3>
            </div>
            <div className="text-2xl font-semibold text-slate-900">
              {status.recent_analyses?.length || 0}
            </div>
            <p className="text-xs text-slate-500 mt-1">Comparisons performed</p>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Commits */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h3 className="text-sm font-semibold text-slate-900">
                Recent Commits
              </h3>
            </div>
            <div className="divide-y divide-slate-100 max-h-[500px] overflow-y-auto">
              {status.recent_commits?.length > 0 ? (
                status.recent_commits.map((commit) => (
                  <div
                    key={commit.sha}
                    className="px-5 py-3 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <GitCommit className="w-4 h-4 text-slate-400 flex-shrink-0 mt-1" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-900 line-clamp-2 mb-1">
                          {commit.message}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-slate-500">
                          <span className="font-mono">
                            {commit.sha.substring(0, 8)}
                          </span>
                          <span>{commit.author_name}</span>
                          <span>
                            {new Date(commit.committed_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="px-5 py-8 text-center text-sm text-slate-500">
                  No commits yet. Click "Sync All" to fetch commits.
                </div>
              )}
            </div>
          </div>

          {/* Recent Deployments */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h3 className="text-sm font-semibold text-slate-900">
                Recent Deployments
              </h3>
            </div>
            <div className="divide-y divide-slate-100 max-h-[500px] overflow-y-auto">
              {status.recent_deployments?.length > 0 ? (
                status.recent_deployments.map((deployment) => (
                  <div
                    key={deployment.deployment_id}
                    className="px-5 py-3 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <Rocket className="w-4 h-4 text-slate-400 flex-shrink-0 mt-1" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full ${
                              deployment.state === "READY"
                                ? "bg-emerald-100 text-emerald-800"
                                : deployment.state === "ERROR"
                                  ? "bg-red-100 text-red-800"
                                  : "bg-slate-100 text-slate-800"
                            }`}
                          >
                            {deployment.state}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500">
                          <span className="font-mono">
                            {deployment.commit_sha?.substring(0, 8) || "N/A"}
                          </span>
                          <span>
                            {new Date(
                              deployment.deployed_at,
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="px-5 py-8 text-center text-sm text-slate-500">
                  No deployments yet. Click "Sync All" to fetch deployments.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Recent Analyses */}
        {status.recent_analyses?.length > 0 && (
          <div className="mt-6 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h3 className="text-sm font-semibold text-slate-900">
                Recent Comparisons
              </h3>
            </div>
            <div className="divide-y divide-slate-100">
              {status.recent_analyses.map((analysis) => (
                <a
                  key={analysis.id}
                  href={`/comparison/${analysis.id}`}
                  className="flex items-center justify-between px-5 py-3 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <FileCode className="w-4 h-4 text-slate-400" />
                    <div>
                      <p className="text-sm text-slate-900 font-mono">
                        {analysis.base_sha.substring(0, 8)} →{" "}
                        {analysis.head_sha.substring(0, 8)}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {analysis.files_changed} files changed •{" "}
                        {new Date(analysis.analyzed_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  {analysis.anomalies && analysis.anomalies.length > 0 && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium bg-amber-100 text-amber-800 rounded-full">
                      <AlertTriangle className="w-3 h-3" />
                      {analysis.anomalies.length}
                    </span>
                  )}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>

      <style jsx global>{`
        .font-inter {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
        
        .overflow-y-auto::-webkit-scrollbar {
          width: 4px;
        }
        
        .overflow-y-auto::-webkit-scrollbar-track {
          background: transparent;
        }
        
        .overflow-y-auto::-webkit-scrollbar-thumb {
          background-color: rgba(148, 163, 184, 0.3);
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
}
