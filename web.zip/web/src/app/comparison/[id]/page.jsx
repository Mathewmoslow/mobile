"use client";

import { useState, useEffect } from "react";
import {
  ArrowLeft,
  AlertTriangle,
  FileCode,
  FilePlus,
  FileX,
  CheckCircle2,
  XCircle,
  Download,
  RefreshCw,
} from "lucide-react";

export default function ComparisonView({ params }) {
  const diffAnalysisId = parseInt(params.id);

  const [diff, setDiff] = useState(null);
  const [confirmations, setConfirmations] = useState({});
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchDiff();
  }, [diffAnalysisId]);

  const fetchDiff = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/analysis/get-diff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ diff_analysis_id: diffAnalysisId }),
      });

      if (!response.ok) throw new Error("Failed to fetch diff");

      const data = await response.json();
      setDiff(data.diff);

      // Initialize confirmations from existing data
      const existingConfirmations = {};
      data.confirmations?.forEach((conf) => {
        const key = `${conf.file_path}:${conf.removal_description}`;
        existingConfirmations[key] = conf.is_intentional;
      });
      setConfirmations(existingConfirmations);
    } catch (error) {
      console.error("Error fetching diff:", error);
    } finally {
      setLoading(false);
    }
  };

  const confirmRemoval = async (
    file_path,
    removal_description,
    is_intentional,
  ) => {
    const key = `${file_path}:${removal_description}`;

    try {
      const response = await fetch("/api/analysis/confirm-removal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          diff_analysis_id: diffAnalysisId,
          file_path,
          removal_description,
          is_intentional,
        }),
      });

      if (!response.ok) throw new Error("Failed to confirm removal");

      setConfirmations({ ...confirmations, [key]: is_intentional });
    } catch (error) {
      console.error("Error confirming removal:", error);
    }
  };

  const exportSnapshot = async () => {
    try {
      setExporting(true);

      const response = await fetch("/api/export/create-snapshot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          repository_id: diff.repository_id,
          commit_sha: diff.head_sha,
          diff_analysis_id: diffAnalysisId,
        }),
      });

      if (!response.ok) throw new Error("Failed to export snapshot");

      const data = await response.json();

      // Download as JSON
      const dataStr = JSON.stringify(data.export_data, null, 2);
      const dataBlob = new Blob([dataStr], { type: "application/json" });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `snapshot-${diff.head_sha.substring(0, 8)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting snapshot:", error);
    } finally {
      setExporting(false);
    }
  };

  if (loading) {
    return (
      <div
        className="min-h-screen font-inter flex items-center justify-center"
        style={{
          background:
            "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
        }}
      >
        <div className="flex items-center gap-3 text-slate-600">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span>Loading comparison...</span>
        </div>
      </div>
    );
  }

  if (!diff) {
    return (
      <div
        className="min-h-screen font-inter flex items-center justify-center"
        style={{
          background:
            "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
        }}
      >
        <div className="text-center">
          <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900 mb-2">
            Comparison not found
          </h3>
          <a href="/" className="text-sm text-slate-600 hover:text-slate-900">
            Back to dashboard
          </a>
        </div>
      </div>
    );
  }

  const diffData = diff.diff_data || {
    additions: [],
    removals: [],
    modifications: [],
  };
  const anomalies = diff.anomalies || [];

  return (
    <div
      className="min-h-screen font-inter"
      style={{
        background:
          "linear-gradient(40deg, #F9F6ED 0%, #F0F0F8 50%, #E7E9FB 100%)",
      }}
    >
      {/* Header */}
      <div className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/"
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </a>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">
                  {diff.github_owner}/{diff.github_repo}
                </h1>
                <p className="text-sm text-slate-600 mt-1 font-mono">
                  {diff.base_sha.substring(0, 8)} →{" "}
                  {diff.head_sha.substring(0, 8)}
                </p>
              </div>
            </div>
            <button
              onClick={exportSnapshot}
              disabled={exporting}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {exporting ? "Exporting..." : "Export for AI"}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <FileCode className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-medium text-slate-900">
                Files Changed
              </h3>
            </div>
            <p className="text-2xl font-semibold text-slate-900">
              {diff.files_changed}
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <FilePlus className="w-4 h-4 text-emerald-500" />
              <h3 className="text-sm font-medium text-slate-900">Additions</h3>
            </div>
            <p className="text-2xl font-semibold text-emerald-600">
              {diffData.additions?.length || 0}
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <FileX className="w-4 h-4 text-red-500" />
              <h3 className="text-sm font-medium text-slate-900">Removals</h3>
            </div>
            <p className="text-2xl font-semibold text-red-600">
              {diffData.removals?.length || 0}
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-medium text-slate-900">Anomalies</h3>
            </div>
            <p className="text-2xl font-semibold text-amber-600">
              {anomalies.length}
            </p>
          </div>
        </div>

        {/* Anomalies Section */}
        {anomalies.length > 0 && (
          <div className="mb-8 bg-amber-50 border border-amber-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-amber-200 bg-amber-100">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <h2 className="text-lg font-semibold text-amber-900">
                  Potential Issues Detected
                </h2>
              </div>
              <p className="text-sm text-amber-800 mt-1">
                These changes might cause problems. Please review carefully.
              </p>
            </div>
            <div className="divide-y divide-amber-200">
              {anomalies.map((anomaly, idx) => (
                <div key={idx} className="px-5 py-4">
                  <div className="flex items-start gap-3">
                    <div
                      className={`flex-shrink-0 w-2 h-2 rounded-full mt-2 ${
                        anomaly.severity === "high"
                          ? "bg-red-500"
                          : "bg-amber-500"
                      }`}
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full ${
                            anomaly.severity === "high"
                              ? "bg-red-100 text-red-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {anomaly.severity?.toUpperCase()}
                        </span>
                        <span className="text-xs font-medium text-slate-600">
                          {anomaly.type}
                        </span>
                      </div>
                      <p className="text-sm text-slate-900 mb-2">
                        {anomaly.message}
                      </p>
                      <p className="text-xs text-slate-600 font-mono">
                        File: {anomaly.file}
                      </p>
                      {anomaly.line && (
                        <p className="text-xs text-slate-600 font-mono mt-1 bg-slate-900 text-slate-100 px-2 py-1 rounded inline-block">
                          {anomaly.line}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Removals Section with Confirmation */}
        {diffData.removals && diffData.removals.length > 0 && (
          <div className="mb-8 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">
                Removals Requiring Confirmation
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Confirm whether these removals were intentional to track
                accidental deletions
              </p>
            </div>
            <div className="divide-y divide-slate-100">
              {diffData.removals.map((removal, idx) => {
                const key = `${removal.filename}:${removal.description}`;
                const isConfirmed = confirmations[key] !== undefined;
                const isIntentional = confirmations[key];

                return (
                  <div key={idx} className="px-5 py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <FileX className="w-4 h-4 text-red-500" />
                          <h3 className="text-sm font-semibold text-slate-900">
                            {removal.filename}
                          </h3>
                        </div>
                        <p className="text-sm text-slate-700 mb-2">
                          {removal.description}
                        </p>
                        {removal.deletions && (
                          <p className="text-xs text-slate-500">
                            {removal.deletions} lines removed
                          </p>
                        )}
                      </div>

                      {isConfirmed ? (
                        <div
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
                            isIntentional
                              ? "bg-emerald-50 text-emerald-800"
                              : "bg-red-50 text-red-800"
                          }`}
                        >
                          {isIntentional ? (
                            <>
                              <CheckCircle2 className="w-4 h-4" />
                              <span className="text-sm font-medium">
                                Intentional
                              </span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-4 h-4" />
                              <span className="text-sm font-medium">
                                Unintentional
                              </span>
                            </>
                          )}
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              confirmRemoval(
                                removal.filename,
                                removal.description,
                                true,
                              )
                            }
                            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            Yes
                          </button>
                          <button
                            onClick={() =>
                              confirmRemoval(
                                removal.filename,
                                removal.description,
                                false,
                              )
                            }
                            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                          >
                            <XCircle className="w-4 h-4" />
                            No
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Additions Section */}
        {diffData.additions && diffData.additions.length > 0 && (
          <div className="mb-8 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">
                New Files Added
              </h2>
            </div>
            <div className="divide-y divide-slate-100">
              {diffData.additions.map((addition, idx) => (
                <div key={idx} className="px-5 py-4">
                  <div className="flex items-start gap-3">
                    <FilePlus className="w-4 h-4 text-emerald-500 mt-1" />
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 mb-1">
                        {addition.filename}
                      </h3>
                      <p className="text-sm text-slate-700 mb-2">
                        {addition.description}
                      </p>
                      {addition.additions && (
                        <p className="text-xs text-slate-500">
                          {addition.additions} lines added
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Modifications Section */}
        {diffData.modifications && diffData.modifications.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">
                Modified Files
              </h2>
            </div>
            <div className="divide-y divide-slate-100">
              {diffData.modifications.map((mod, idx) => (
                <div key={idx} className="px-5 py-4">
                  <div className="flex items-start gap-3">
                    <FileCode className="w-4 h-4 text-blue-500 mt-1" />
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-slate-900 mb-2">
                        {mod.filename}
                      </h3>
                      <div className="flex items-center gap-4 text-xs">
                        <span className="text-emerald-600">
                          +{mod.additions || 0}
                        </span>
                        <span className="text-red-600">
                          -{mod.deletions || 0}
                        </span>
                        <span className="text-slate-500">
                          {mod.changes || 0} changes
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style jsx global>{`
        .font-inter {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
      `}</style>
    </div>
  );
}
