import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id, commit_sha, diff_analysis_id } = body;

    if (!repository_id || !commit_sha) {
      return Response.json(
        { error: "repository_id and commit_sha are required" },
        { status: 400 },
      );
    }

    // Get repository
    const [repository] = await sql`
      SELECT * FROM repositories WHERE id = ${repository_id}
    `;

    if (!repository) {
      return Response.json({ error: "Repository not found" }, { status: 404 });
    }

    // Get commit details
    const [commit] = await sql`
      SELECT * FROM commits WHERE sha = ${commit_sha} AND repository_id = ${repository_id}
    `;

    // Get diff analysis if provided
    let diffAnalysis = null;
    if (diff_analysis_id) {
      const [analysis] = await sql`
        SELECT * FROM diff_analyses WHERE id = ${diff_analysis_id}
      `;
      diffAnalysis = analysis;
    }

    // Create export data
    const exportData = {
      repository: {
        owner: repository.github_owner,
        repo: repository.github_repo,
      },
      commit: {
        sha: commit_sha,
        message: commit?.message,
        author: commit?.author_name,
        date: commit?.committed_at,
      },
      diff_analysis: diffAnalysis
        ? {
            base_sha: diffAnalysis.base_sha,
            head_sha: diffAnalysis.head_sha,
            files_changed: diffAnalysis.files_changed,
            diff_data: diffAnalysis.diff_data,
            anomalies: diffAnalysis.anomalies,
          }
        : null,
      export_metadata: {
        created_at: new Date().toISOString(),
        format: "ai_handoff_v1",
      },
      instructions_for_ai: {
        context: `This is a code snapshot for ${repository.github_owner}/${repository.github_repo} at commit ${commit_sha}.`,
        usage:
          "Use this data to understand code changes and apply fixes without introducing errors.",
        diff_summary: diffAnalysis
          ? {
              files_changed: diffAnalysis.files_changed,
              has_anomalies: (diffAnalysis.anomalies?.length || 0) > 0,
              anomaly_count: diffAnalysis.anomalies?.length || 0,
            }
          : null,
      },
    };

    // Store export snapshot
    const [snapshot] = await sql`
      INSERT INTO export_snapshots (
        repository_id,
        commit_sha,
        export_data
      ) VALUES (
        ${repository_id},
        ${commit_sha},
        ${JSON.stringify(exportData)}
      )
      RETURNING *
    `;

    return Response.json({
      snapshot,
      export_data: exportData,
    });
  } catch (error) {
    console.error("Error creating export snapshot:", error);
    return Response.json(
      { error: "Failed to create export snapshot" },
      { status: 500 },
    );
  }
}
