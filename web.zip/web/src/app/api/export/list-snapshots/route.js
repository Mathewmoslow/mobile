import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id } = body;

    if (!repository_id) {
      return Response.json(
        { error: "repository_id is required" },
        { status: 400 },
      );
    }

    const snapshots = await sql`
      SELECT 
        es.*,
        c.message as commit_message,
        c.author_name,
        c.committed_at
      FROM export_snapshots es
      LEFT JOIN commits c ON c.sha = es.commit_sha AND c.repository_id = es.repository_id
      WHERE es.repository_id = ${repository_id}
      ORDER BY es.created_at DESC
      LIMIT 20
    `;

    return Response.json({ snapshots });
  } catch (error) {
    console.error("Error fetching export snapshots:", error);
    return Response.json(
      { error: "Failed to fetch export snapshots" },
      { status: 500 },
    );
  }
}
