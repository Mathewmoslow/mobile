import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { diff_analysis_id, file_path, removal_description, is_intentional } =
      body;

    if (
      !diff_analysis_id ||
      !file_path ||
      !removal_description ||
      is_intentional === undefined
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [confirmation] = await sql`
      INSERT INTO removal_confirmations (
        diff_analysis_id,
        file_path,
        removal_description,
        is_intentional
      ) VALUES (
        ${diff_analysis_id},
        ${file_path},
        ${removal_description},
        ${is_intentional}
      )
      RETURNING *
    `;

    return Response.json({ confirmation });
  } catch (error) {
    console.error("Error creating removal confirmation:", error);
    return Response.json(
      { error: "Failed to create removal confirmation" },
      { status: 500 },
    );
  }
}
