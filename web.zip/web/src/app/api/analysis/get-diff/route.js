import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { diff_analysis_id } = body;

    if (!diff_analysis_id) {
      return Response.json(
        { error: "diff_analysis_id is required" },
        { status: 400 },
      );
    }

    const [diff] = await sql`
      SELECT 
        da.*,
        r.github_owner,
        r.github_repo,
        (SELECT message FROM commits WHERE sha = da.base_sha AND repository_id = da.repository_id LIMIT 1) as base_message,
        (SELECT message FROM commits WHERE sha = da.head_sha AND repository_id = da.repository_id LIMIT 1) as head_message
      FROM diff_analyses da
      JOIN repositories r ON r.id = da.repository_id
      WHERE da.id = ${diff_analysis_id}
    `;

    if (!diff) {
      return Response.json(
        { error: "Diff analysis not found" },
        { status: 404 },
      );
    }

    // Get removal confirmations
    const confirmations = await sql`
      SELECT * FROM removal_confirmations
      WHERE diff_analysis_id = ${diff_analysis_id}
    `;

    return Response.json({
      diff,
      confirmations,
    });
  } catch (error) {
    console.error("Error fetching diff analysis:", error);
    return Response.json(
      { error: "Failed to fetch diff analysis" },
      { status: 500 },
    );
  }
}
