import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id, base_sha, head_sha } = body;

    if (!repository_id || !base_sha || !head_sha) {
      return Response.json(
        { error: "repository_id, base_sha, and head_sha are required" },
        { status: 400 },
      );
    }

    // Get repository details
    const [repo] = await sql`
      SELECT * FROM repositories WHERE id = ${repository_id}
    `;

    if (!repo) {
      return Response.json({ error: "Repository not found" }, { status: 404 });
    }

    const github_token = process.env[repo.github_token_env_var];
    if (!github_token) {
      return Response.json(
        {
          error: `GitHub token not found in environment variable: ${repo.github_token_env_var}`,
        },
        { status: 400 },
      );
    }

    // Fetch comparison from GitHub
    const url = `https://api.github.com/repos/${repo.github_owner}/${repo.github_repo}/compare/${base_sha}...${head_sha}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `token ${github_token}`,
        Accept: "application/vnd.github.v3+json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("GitHub API error:", errorText);
      return Response.json(
        {
          error: `GitHub API error: ${response.status} ${response.statusText}`,
        },
        { status: response.status },
      );
    }

    const comparison = await response.json();

    // Analyze the diff for changes, removals, and anomalies
    const analysis = analyzeDiff(comparison.files || []);

    // Store diff analysis in database
    const [diff_analysis] = await sql`
      INSERT INTO diff_analyses (
        repository_id,
        base_sha,
        head_sha,
        files_changed,
        additions_count,
        deletions_count,
        diff_data,
        anomalies
      ) VALUES (
        ${repository_id},
        ${base_sha},
        ${head_sha},
        ${comparison.files?.length || 0},
        ${comparison.total_commits || 0},
        ${comparison.total_commits || 0},
        ${JSON.stringify(analysis.diff_data)},
        ${JSON.stringify(analysis.anomalies)}
      )
      ON CONFLICT (repository_id, base_sha, head_sha) DO UPDATE SET
        files_changed = EXCLUDED.files_changed,
        additions_count = EXCLUDED.additions_count,
        deletions_count = EXCLUDED.deletions_count,
        diff_data = EXCLUDED.diff_data,
        anomalies = EXCLUDED.anomalies,
        analyzed_at = NOW()
      RETURNING *
    `;

    return Response.json({
      comparison,
      analysis,
      diff_analysis_id: diff_analysis.id,
    });
  } catch (error) {
    console.error("Error comparing commits:", error);
    return Response.json(
      { error: "Failed to compare commits" },
      { status: 500 },
    );
  }
}

function analyzeDiff(files) {
  const diff_data = {
    additions: [],
    removals: [],
    modifications: [],
  };
  const anomalies = [];

  for (const file of files) {
    const fileInfo = {
      filename: file.filename,
      status: file.status,
      additions: file.additions,
      deletions: file.deletions,
      changes: file.changes,
    };

    if (file.status === "removed") {
      diff_data.removals.push({
        ...fileInfo,
        description: `Entire file removed: ${file.filename}`,
      });

      // Flag as anomaly - file removal
      anomalies.push({
        type: "file_removal",
        severity: "high",
        file: file.filename,
        message: `File completely removed: ${file.filename}`,
      });
    } else if (file.status === "added") {
      diff_data.additions.push({
        ...fileInfo,
        description: `New file added: ${file.filename}`,
      });
    } else if (file.status === "modified" || file.status === "renamed") {
      diff_data.modifications.push(fileInfo);

      // Analyze patch for specific patterns
      if (file.patch) {
        const lines = file.patch.split("\n");

        for (const line of lines) {
          // Check for removed imports
          if (line.startsWith("-") && !line.startsWith("---")) {
            const trimmedLine = line.substring(1).trim();

            if (
              trimmedLine.includes("import ") ||
              trimmedLine.includes("require(")
            ) {
              anomalies.push({
                type: "removed_import",
                severity: "medium",
                file: file.filename,
                line: trimmedLine,
                message: `Removed import in ${file.filename}: ${trimmedLine}`,
              });
            }

            if (
              trimmedLine.includes("export ") ||
              trimmedLine.includes("function ") ||
              trimmedLine.includes("const ") ||
              trimmedLine.includes("class ")
            ) {
              anomalies.push({
                type: "removed_declaration",
                severity: "high",
                file: file.filename,
                line: trimmedLine,
                message: `Removed declaration in ${file.filename}: ${trimmedLine}`,
              });
            }
          }
        }
      }

      // Large deletions
      if (file.deletions > 50) {
        anomalies.push({
          type: "large_deletion",
          severity: "medium",
          file: file.filename,
          deletions: file.deletions,
          message: `Large deletion in ${file.filename}: ${file.deletions} lines removed`,
        });
      }
    }
  }

  return { diff_data, anomalies };
}
