import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id, num_commits = 10 } = body;

    if (!repository_id) {
      return Response.json(
        { error: "Repository ID is required" },
        { status: 400 },
      );
    }

    // Get repository details
    const [repo] = await sql`
      SELECT * FROM repositories WHERE id = ${repository_id}
    `;

    if (!repo) {
      return Response.json({ error: "Repository not found" }, { status: 404 });
    }

    const github_token = process.env[repo.github_token_env_var];
    if (!github_token) {
      return Response.json(
        {
          error: `GitHub token not found in environment variable: ${repo.github_token_env_var}`,
        },
        { status: 400 },
      );
    }

    // Fetch commits from GitHub
    const url = `https://api.github.com/repos/${repo.github_owner}/${repo.github_repo}/commits?per_page=${num_commits}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `token ${github_token}`,
        Accept: "application/vnd.github.v3+json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("GitHub API error:", errorText);
      return Response.json(
        {
          error: `GitHub API error: ${response.status} ${response.statusText}`,
        },
        { status: response.status },
      );
    }

    const commits = await response.json();

    // Store commits in database
    for (const commit of commits) {
      await sql`
        INSERT INTO commits (
          repository_id,
          sha,
          message,
          author_name,
          author_email,
          committed_at
        ) VALUES (
          ${repository_id},
          ${commit.sha},
          ${commit.commit.message},
          ${commit.commit.author.name},
          ${commit.commit.author.email},
          ${commit.commit.author.date}
        )
        ON CONFLICT (repository_id, sha) DO UPDATE SET
          message = EXCLUDED.message,
          author_name = EXCLUDED.author_name,
          author_email = EXCLUDED.author_email,
          committed_at = EXCLUDED.committed_at
      `;
    }

    // Update last_synced_at
    await sql`
      UPDATE repositories
      SET last_synced_at = NOW()
      WHERE id = ${repository_id}
    `;

    return Response.json({
      success: true,
      commits_fetched: commits.length,
    });
  } catch (error) {
    console.error("Error fetching GitHub commits:", error);
    return Response.json(
      { error: "Failed to fetch GitHub commits" },
      { status: 500 },
    );
  }
}
