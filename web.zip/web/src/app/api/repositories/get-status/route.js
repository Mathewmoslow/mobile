import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id } = body;

    if (!repository_id) {
      return Response.json(
        { error: "repository_id is required" },
        { status: 400 },
      );
    }

    // Get repository
    const [repository] = await sql`
      SELECT * FROM repositories WHERE id = ${repository_id}
    `;

    if (!repository) {
      return Response.json({ error: "Repository not found" }, { status: 404 });
    }

    // Get latest commit from GitHub
    const latestCommit = await sql`
      SELECT * FROM commits
      WHERE repository_id = ${repository_id}
      ORDER BY committed_at DESC
      LIMIT 1
    `;

    // Get latest deployment from Vercel
    const latestDeployment = await sql`
      SELECT * FROM deployments
      WHERE repository_id = ${repository_id}
      ORDER BY deployed_at DESC
      LIMIT 1
    `;

    // Get recent commits
    const recentCommits = await sql`
      SELECT * FROM commits
      WHERE repository_id = ${repository_id}
      ORDER BY committed_at DESC
      LIMIT 10
    `;

    // Get recent deployments
    const recentDeployments = await sql`
      SELECT * FROM deployments
      WHERE repository_id = ${repository_id}
      ORDER BY deployed_at DESC
      LIMIT 10
    `;

    // Check if there's a mismatch
    const mismatch =
      latestCommit[0] &&
      latestDeployment[0] &&
      latestCommit[0].sha !== latestDeployment[0].commit_sha;

    // Get recent analyses
    const recentAnalyses = await sql`
      SELECT * FROM diff_analyses
      WHERE repository_id = ${repository_id}
      ORDER BY analyzed_at DESC
      LIMIT 5
    `;

    return Response.json({
      repository,
      latest_commit: latestCommit[0] || null,
      latest_deployment: latestDeployment[0] || null,
      recent_commits: recentCommits,
      recent_deployments: recentDeployments,
      recent_analyses: recentAnalyses,
      has_mismatch: mismatch,
    });
  } catch (error) {
    console.error("Error fetching repository status:", error);
    return Response.json(
      { error: "Failed to fetch repository status" },
      { status: 500 },
    );
  }
}
