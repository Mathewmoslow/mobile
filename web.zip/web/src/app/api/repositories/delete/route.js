import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { id } = body;

    if (!id) {
      return Response.json(
        { error: "Repository ID is required" },
        { status: 400 },
      );
    }

    await sql`
      DELETE FROM repositories
      WHERE id = ${id}
    `;

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error deleting repository:", error);
    return Response.json(
      { error: "Failed to delete repository" },
      { status: 500 },
    );
  }
}
