import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      github_owner,
      github_repo,
      github_token_env_var,
      vercel_project_id,
      vercel_token_env_var,
    } = body;

    if (
      !github_owner ||
      !github_repo ||
      !github_token_env_var ||
      !vercel_project_id ||
      !vercel_token_env_var
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [repository] = await sql`
      INSERT INTO repositories (
        github_owner,
        github_repo,
        github_token_env_var,
        vercel_project_id,
        vercel_token_env_var
      ) VALUES (
        ${github_owner},
        ${github_repo},
        ${github_token_env_var},
        ${vercel_project_id},
        ${vercel_token_env_var}
      )
      RETURNING *
    `;

    return Response.json({ repository });
  } catch (error) {
    console.error("Error creating repository:", error);
    return Response.json(
      { error: "Failed to create repository" },
      { status: 500 },
    );
  }
}
