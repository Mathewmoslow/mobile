import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const repositories = await sql`
      SELECT 
        id,
        github_owner,
        github_repo,
        vercel_project_id,
        last_synced_at,
        created_at
      FROM repositories
      ORDER BY created_at DESC
    `;

    return Response.json({ repositories });
  } catch (error) {
    console.error("Error fetching repositories:", error);
    return Response.json(
      { error: "Failed to fetch repositories" },
      { status: 500 },
    );
  }
}
