import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { repository_id, limit = 20 } = body;

    if (!repository_id) {
      return Response.json(
        { error: "Repository ID is required" },
        { status: 400 },
      );
    }

    // Get repository details
    const [repo] = await sql`
      SELECT * FROM repositories WHERE id = ${repository_id}
    `;

    if (!repo) {
      return Response.json({ error: "Repository not found" }, { status: 404 });
    }

    const vercel_token = process.env[repo.vercel_token_env_var];
    if (!vercel_token) {
      return Response.json(
        {
          error: `Vercel token not found in environment variable: ${repo.vercel_token_env_var}`,
        },
        { status: 400 },
      );
    }

    // Fetch deployments from Vercel
    const url = `https://api.vercel.com/v6/deployments?projectId=${repo.vercel_project_id}&limit=${limit}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${vercel_token}`,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Vercel API error:", errorText);
      return Response.json(
        {
          error: `Vercel API error: ${response.status} ${response.statusText}`,
        },
        { status: response.status },
      );
    }

    const data = await response.json();
    const deployments = data.deployments || [];

    // Store deployments in database
    for (const deployment of deployments) {
      const commit_sha = deployment.meta?.githubCommitSha || null;

      await sql`
        INSERT INTO deployments (
          repository_id,
          deployment_id,
          commit_sha,
          state,
          url,
          deployed_at
        ) VALUES (
          ${repository_id},
          ${deployment.uid},
          ${commit_sha},
          ${deployment.state},
          ${deployment.url},
          ${new Date(deployment.created).toISOString()}
        )
        ON CONFLICT (deployment_id) DO UPDATE SET
          state = EXCLUDED.state,
          url = EXCLUDED.url
      `;
    }

    return Response.json({
      success: true,
      deployments_fetched: deployments.length,
    });
  } catch (error) {
    console.error("Error fetching Vercel deployments:", error);
    return Response.json(
      { error: "Failed to fetch Vercel deployments" },
      { status: 500 },
    );
  }
}
